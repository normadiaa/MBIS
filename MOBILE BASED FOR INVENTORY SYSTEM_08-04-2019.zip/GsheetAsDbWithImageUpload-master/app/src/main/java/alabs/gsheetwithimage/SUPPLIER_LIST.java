package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;



public class SUPPLIER_LIST extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, AdapterView.OnItemClickListener {

    private Toolbar toolbar;
    private DrawerLayout drawer;
    private FloatingActionButton fab;
    ListView lvsupplier;
    ListAdapter adapter;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplier__list);

        fab = (FloatingActionButton)findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SUPPLIER_LIST.this, SUPPLIER_INFORMATION.class);
                startActivity(intent);
            }
        });


        lvsupplier = (ListView) findViewById(R.id.lvSupplier);
        //sendRequest();
        getSuppliers();

        lvsupplier.setOnItemClickListener(this);


       /* lvsupplier.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent suppinfo = new Intent(SUPPLIER_LIST.this, SUPPLIER_UPDATE_DELETE.class);
                startActivity(suppinfo);

            }
        });
        */


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // ***** drawer *****
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();



    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.inventory:
                Intent intentinventory = new Intent(SUPPLIER_LIST.this, PRODUCT_LIST.class);
                startActivity(intentinventory);
                break;
            case R.id.sales:
                Intent intentsales = new Intent(SUPPLIER_LIST.this, SALE.class);
                startActivity(intentsales);
                break;
            case R.id.supplier:
                Intent intentsupplier = new Intent(SUPPLIER_LIST.this, SUPPLIER_LIST.class);
                startActivity(intentsupplier);
                break;
            case R.id.purchases:
                Intent intentpurchases = new Intent(SUPPLIER_LIST.this, PURCHASE.class);
                startActivity(intentpurchases);
                break;
            case R.id.customer:
                Intent intentcustomer = new Intent(SUPPLIER_LIST.this, CUSTOMER_LIST.class);
                startActivity(intentcustomer);
                break;
        }

        return false;
    }

    // ***** drawer *****
    public void onBackPressed(){
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);

        }else{
            super.onBackPressed();
        }
    }






    private void getSuppliers() {

        loading = ProgressDialog.show(this, "Loading", "please wait", false, true);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://script.google.com/macros/s/AKfycbzPZM1GYn6YY3MxwDfyYsQjcdmpLn-2Gi7x9WNGAoS2ZDhi_zQ/exec?action=getItems",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SUPPLIER_LIST.this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    private void parseItems (String jsonResposnce) {

        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            JSONObject jobj = new JSONObject(jsonResposnce);
            JSONArray jarray = jobj.getJSONArray("items");


            for (int i = 0; i < jarray.length(); i++) {

                JSONObject jo = jarray.getJSONObject(i);

                String MBIS_SuppCompany = jo.getString("MBIS_SuppCompany");
                String MBIS_SuppName = jo.getString("MBIS_SuppName");
                String MBIS_SuppPhoneNum = jo.getString("MBIS_SuppPhoneNum");
                String MBIS_SuppEmail = jo.getString("MBIS_SuppEmail");
                String MBIS_SuppAddress = jo.getString("MBIS_SuppAddress");



                HashMap<String, String> item = new HashMap<>();
                item.put("MBIS_SuppCompany", MBIS_SuppCompany);
                item.put("MBIS_SuppName", MBIS_SuppName);
                item.put("MBIS_SuppPhoneNum",MBIS_SuppPhoneNum);
                item.put("MBIS_SuppEmail",MBIS_SuppEmail);
                item.put("MBIS_SuppAddress",MBIS_SuppAddress);


                list.add(item);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapter = new SimpleAdapter(this,list,R.layout.supplierlist_row,
                new String[]{"MBIS_SuppCompany", "MBIS_SuppName", "MBIS_SuppPhoneNum", "MBIS_SuppEmail", "MBIS_SuppAddress"},new int[]{R.id.tv_suppCompany});


        lvsupplier.setAdapter(adapter);
        loading.dismiss();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        Intent intent = new Intent(this, SUPPLIER_UPDATE_DELETE.class);
        HashMap<String,String> map =(HashMap)parent.getItemAtPosition(position);

        String MBIS_SuppCompany = map.get("MBIS_SuppCompany").toString();
        String MBIS_SuppName = map.get("MBIS_SuppName").toString();
        String MBIS_SuppPhoneNum = map.get("MBIS_SuppPhoneNum").toString();
        String MBIS_SuppEmail = map.get("MBIS_SuppEmail").toString();
        String MBIS_SuppAddress = map.get("MBIS_SuppAddress").toString();


        // String sno = map.get("sno").toString();

        // Log.e("SNO test",sno);
        intent.putExtra("MBIS_SuppCompany",MBIS_SuppCompany);
        intent.putExtra("MBIS_SuppName",MBIS_SuppName);
        intent.putExtra("MBIS_SuppPhoneNum",MBIS_SuppPhoneNum);
        intent.putExtra("MBIS_SuppEmail",MBIS_SuppEmail);
        intent.putExtra("MBIS_SuppAddress",MBIS_SuppAddress);


        startActivity(intent);

    }















/*
    private void sendRequest(){
        final ProgressDialog loading = ProgressDialog.show(this,"Uploading...","Please wait...",false,false);

        StringRequest stringRequest = new StringRequest(LIST_SUPPLIER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Log.e("null","ser image"+response);
                        showJSON(response);

                        loading.dismiss();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SUPPLIER_LIST.this,error.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });

        int socketTimeout = 30000; // 30 seconds. You can change it
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showJSON(String json){
        Supplier_JsonParser sj = new Supplier_JsonParser(json);
        sj.parseJSON();

        SupplierList_Adapter supplierList_adapter = new SupplierList_Adapter(this, Supplier_JsonParser.MBIS_SuppCompany, Supplier_JsonParser.MBIS_SuppName, Supplier_JsonParser.MBIS_SuppPhoneNum, Supplier_JsonParser.MBIS_SuppEmail, Supplier_JsonParser.MBIS_SuppAddress);
        lvsupplier.setAdapter(supplierList_adapter);
    }

*/

}
