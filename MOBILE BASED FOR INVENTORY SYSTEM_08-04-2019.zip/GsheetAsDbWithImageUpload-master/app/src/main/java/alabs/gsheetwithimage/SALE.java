package alabs.gsheetwithimage;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import static alabs.gsheetwithimage.Product_Configuration.LIST_USER_URL;

public class SALE extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, AdapterView.OnItemClickListener {

    private DrawerLayout drawer;

    ListView lv_Sale;
    ListAdapter adapter;
    ProgressDialog loading;
    Button history;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sale);

        history=(Button)findViewById(R.id.btn_SaleHistory);

        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent saleHistory = new Intent(SALE.this, SALE_HISTORY.class);
                startActivity(saleHistory);

            }
        });


        lv_Sale = (ListView) findViewById(R.id.lv_product);
        getProducts();


        lv_Sale.setOnItemClickListener(this);





        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // ***** drawer *****
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


    }

    public void onBackPressed(){
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        switch (menuItem.getItemId()){
            case R.id.inventory:
                Intent intentinventory = new Intent(SALE.this, PRODUCT_LIST.class);
                startActivity(intentinventory);
                break;
            case R.id.sales:
                Intent intentsales = new Intent(SALE.this, SALE.class);
                startActivity(intentsales);
                break;
            case R.id.supplier:
                Intent intentsupplier = new Intent(SALE.this, SUPPLIER_LIST.class);
                startActivity(intentsupplier);
                break;
            case R.id.purchases:
                Intent intentpurchases = new Intent(SALE.this, PURCHASE.class);
                startActivity(intentpurchases);
                break;
            case R.id.customer:
                Intent intentcustomer = new Intent(SALE.this, CUSTOMER_LIST.class);
                startActivity(intentcustomer);
                break;
        }
        return true;
    }


/* ####################################################################################################################################################### */


    private void getProducts() {

        loading = ProgressDialog.show(this, "Loading", "please wait", false, true);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://script.google.com/macros/s/AKfycbzL1kvM_ZCq9uYtLI8rZVXAP8Eqg86ZedGIRJNDXTXtvCQU8YIA/exec?action=getItems",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SALE.this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    private void parseItems (String jsonResposnce) {

        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            JSONObject jobj = new JSONObject(jsonResposnce);
            JSONArray jarray = jobj.getJSONArray("items");


            for (int i = 0; i < jarray.length(); i++) {

                JSONObject jo = jarray.getJSONObject(i);

                String MBIS_ProductBarcode = jo.getString("MBIS_ProductBarcode");
                String MBIS_ProductName = jo.getString("MBIS_ProductName");
                String MBIS_ProductQuantity = jo.getString("MBIS_ProductQuantity");
                String MBIS_ProductPurchasesPrice = jo.getString("MBIS_ProductPurchasesPrice");
                String MBIS_ProductSalesPrice = jo.getString("MBIS_ProductSalesPrice");
                String MBIS_ProductInformation = jo.getString("MBIS_ProductInformation");
                String MBIS_ProductImage = jo.getString("MBIS_ProductImage");




                HashMap<String, String> item = new HashMap<>();
                item.put("MBIS_ProductBarcode", MBIS_ProductBarcode);
                item.put("MBIS_ProductName", MBIS_ProductName);
                item.put("MBIS_ProductQuantity",MBIS_ProductQuantity);
                item.put("MBIS_ProductPurchasesPrice",MBIS_ProductPurchasesPrice);
                item.put("MBIS_ProductSalesPrice", MBIS_ProductSalesPrice);
                item.put("MBIS_ProductInformation",MBIS_ProductInformation);
                item.put("MBIS_ProductImage",MBIS_ProductImage);

                //Picasso.with(mContext).load(item.getImage()).into(holder.imageView);



                list.add(item);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapter = new SimpleAdapter(this,list,R.layout.productlist_row,
                new String[]{"MBIS_ProductBarcode", "MBIS_ProductName", "MBIS_ProductQuantity", "MBIS_ProductSalesPrice", "MBIS_ProductImage", "MBIS_ProductPurchasesPrice", "MBIS_ProductInformation"},
                new int[]{R.id.tv_code, R.id.tv_CustName, R.id.tv_quantity, R.id.tv_sales, R.id.imageView3});


        lv_Sale.setAdapter(adapter);


        loading.dismiss();
    }


/* ####################################################################################################################################################### */

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, SALE_INFORMATION.class);
        HashMap<String,String> map =(HashMap)parent.getItemAtPosition(position);

        String MBIS_ProductBarcode = map.get("MBIS_ProductBarcode").toString();
        String MBIS_ProductName = map.get("MBIS_ProductName").toString();
        String MBIS_ProductSalesPrice = map.get("MBIS_ProductSalesPrice").toString();

        intent.putExtra("MBIS_ProductBarcode",MBIS_ProductBarcode);
        intent.putExtra("MBIS_ProductName",MBIS_ProductName);
        intent.putExtra("MBIS_ProductSalesPrice",MBIS_ProductSalesPrice);



        startActivity(intent);




    }

/* ####################################################################################################################################################### */



}
