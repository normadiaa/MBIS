package alabs.gsheetwithimage;

/**
 * Created by ADJ on 8/8/2017.
 */


import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;


public class ProductList_Adapter extends ArrayAdapter<String> {
    private String[] MBIS_ProductBarcode;
    private String[] MBIS_ProductName;
    private String[] MBIS_ProductQuantity;
    private String[] MBIS_ProductPurchasesPrice;
    private String[] MBIS_ProductSalesPrice;
    private String[] MBIS_ProductInformation;
    private String[] MBIS_ProductImage;

    private Activity context;

    public ProductList_Adapter(Activity context, String[] MBIS_ProductBarcode, String[] MBIS_ProductName, String[] MBIS_ProductQuantity, String[] MBIS_ProductPurchasesPrice, String[] MBIS_ProductSalesPrice, String[] MBIS_ProductInformation, String[] MBIS_ProductImage){
        super(context, R.layout.productlist_row, MBIS_ProductBarcode);

        this.context = context;
        this.MBIS_ProductBarcode = MBIS_ProductBarcode;
        this.MBIS_ProductName = MBIS_ProductName;
        this.MBIS_ProductQuantity = MBIS_ProductQuantity;
        this.MBIS_ProductPurchasesPrice = MBIS_ProductPurchasesPrice;
        this.MBIS_ProductSalesPrice = MBIS_ProductSalesPrice;
        this.MBIS_ProductInformation = MBIS_ProductInformation;
        this.MBIS_ProductImage = MBIS_ProductImage;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.productlist_row, null, true);

        TextView textViewCode = (TextView) listViewItem.findViewById(R.id.tv_code);
        TextView textViewName = (TextView) listViewItem.findViewById(R.id.tv_CustName);
        TextView textViewQuantity = (TextView)listViewItem.findViewById(R.id.tv_quantity);
       // TextView textViewPurchases = (TextView) listViewItem.findViewById(R.id.tv_purchases);
        TextView textViewSales = (TextView) listViewItem.findViewById(R.id.tv_sales);
       // TextView textViewInfo = (TextView)listViewItem.findViewById(R.id.tv_info);
        ImageView iv = (ImageView)listViewItem.findViewById(R.id.imageView3);


        textViewCode.setText(MBIS_ProductBarcode[position]);
        textViewName.setText(MBIS_ProductName[position]);
        textViewQuantity.setText(MBIS_ProductQuantity[position]);
        //textViewPurchases.setText(MBIS_ProductPurchasesPrice[position]);
        textViewSales.setText(MBIS_ProductSalesPrice[position]);
       // textViewInfo.setText(MBIS_ProductInformation[position]);
        // Uri uri = Uri.parse(uImages[position]);
        //Uri uri = Uri.parse("https://drive.google.com/uc?id=0B___GhMLUVtOY09SbDU5cDU2T1U");
        // draweeView.setImageURI(uri);

        Picasso.with(context).load(MBIS_ProductImage[position]).into(iv);

        return listViewItem;
    }
}