package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;



public class CUSTOMER_LIST extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, AdapterView.OnItemClickListener {

    private Toolbar toolbar;
    private DrawerLayout drawer;
    private FloatingActionButton fab;
    ListView lvcustomer;
    ListAdapter adapter;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer__list);

        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(CUSTOMER_LIST.this, CUSTOMER_INFORMATION.class);
                startActivity(intent);
            }
        });


        lvcustomer = (ListView) findViewById(R.id.lvCustomer);
        getCustomers();
        //sendRequest();

        lvcustomer.setOnItemClickListener(this);

        /*lvcustomer.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent custinfo = new Intent(CUSTOMER_LIST.this, CUSTOMER_UPDATE_DELETE.class);
                startActivity(custinfo);

            }
        });
        */



        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // ***** drawer *****
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.inventory:
                Intent intentinventory = new Intent(CUSTOMER_LIST.this, PRODUCT_LIST.class);
                startActivity(intentinventory);
                break;
            case R.id.sales:
                Intent intentsales = new Intent(CUSTOMER_LIST.this, SALE.class);
                startActivity(intentsales);
                break;
            case R.id.supplier:
                Intent intentsupplier = new Intent(CUSTOMER_LIST.this, SUPPLIER_LIST.class);
                startActivity(intentsupplier);
                break;
            case R.id.purchases:
                Intent intentpurchases = new Intent(CUSTOMER_LIST.this, PURCHASE.class);
                startActivity(intentpurchases);
                break;
            case R.id.customer:
                Intent intentcustomer = new Intent(CUSTOMER_LIST.this, CUSTOMER_LIST.class);
                startActivity(intentcustomer);
                break;
        }

        return false;
    }

    // ***** drawer *****
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);

        } else {
            super.onBackPressed();
        }
    }



    private void getCustomers() {

        loading = ProgressDialog.show(this, "Loading", "please wait", false, true);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://script.google.com/macros/s/AKfycbwmLbiLVUF-dbwGDNuVH2YL-Q1Wh8mEWzAbdcsh3D2C1Ojd0Grl/exec?action=getItems",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(CUSTOMER_LIST.this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

        private void parseItems (String jsonResposnce) {

            ArrayList<HashMap<String, String>> list = new ArrayList<>();

            try {
                JSONObject jobj = new JSONObject(jsonResposnce);
                JSONArray jarray = jobj.getJSONArray("items");


                for (int i = 0; i < jarray.length(); i++) {

                    JSONObject jo = jarray.getJSONObject(i);

                    String MBIS_CustName = jo.getString("MBIS_CustName");
                    String MBIS_CustPhoneNum = jo.getString("MBIS_CustPhoneNum");
                    String MBIS_CustEmail = jo.getString("MBIS_CustEmail");
                    String MBIS_CustAddress = jo.getString("MBIS_CustAddress");



                    HashMap<String, String> item = new HashMap<>();
                    item.put("MBIS_CustName", MBIS_CustName);
                    item.put("MBIS_CustPhoneNum", MBIS_CustPhoneNum);
                    item.put("MBIS_CustEmail",MBIS_CustEmail);
                    item.put("MBIS_CustAddress",MBIS_CustAddress);


                    list.add(item);


                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


            adapter = new SimpleAdapter(this,list,R.layout.customerlist_row,
                    new String[]{"MBIS_CustName", "MBIS_CustPhoneNum", "MBIS_CustEmail", "MBIS_CustAddress"},new int[]{R.id.tv_CustName});


            lvcustomer.setAdapter(adapter);
            loading.dismiss();
        }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, CUSTOMER_UPDATE_DELETE.class);
        HashMap<String,String> map =(HashMap)parent.getItemAtPosition(position);
        String MBIS_CustName = map.get("MBIS_CustName").toString();
        String MBIS_CustPhoneNum = map.get("MBIS_CustPhoneNum").toString();
        String MBIS_CustEmail = map.get("MBIS_CustEmail").toString();
        String MBIS_CustAddress = map.get("MBIS_CustAddress").toString();


        // String sno = map.get("sno").toString();

        // Log.e("SNO test",sno);
        intent.putExtra("MBIS_CustName",MBIS_CustName);
        intent.putExtra("MBIS_CustPhoneNum",MBIS_CustPhoneNum);
        intent.putExtra("MBIS_CustEmail",MBIS_CustEmail);
        intent.putExtra("MBIS_CustAddress",MBIS_CustAddress);


        startActivity(intent);
}







/*
    private void sendRequest() {
        final ProgressDialog loading = ProgressDialog.show(this, "Uploading...", "Please wait...", false, false);

        StringRequest stringRequest = new StringRequest(LIST_CUSTOMER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Log.e("null","ser image"+response);
                        showJSON(response);

                        loading.dismiss();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(CUSTOMER_LIST.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        int socketTimeout = 30000; // 30 seconds. You can change it
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showJSON(String json) {

        Customer_JsonParser customer_jsonParser = new Customer_JsonParser(json);
        customer_jsonParser.parseJSON();

        CustomerList_Adapter customerList_adapter = new CustomerList_Adapter(this, Customer_JsonParser.MBIS_CustomerName, Customer_JsonParser.MBIS_CustomerPhoneNumber, Customer_JsonParser.MBIS_CustomerEmail, Customer_JsonParser.MBIS_CustomerAddress);
        lvcustomer.setAdapter(customerList_adapter);
    }
*/



}


