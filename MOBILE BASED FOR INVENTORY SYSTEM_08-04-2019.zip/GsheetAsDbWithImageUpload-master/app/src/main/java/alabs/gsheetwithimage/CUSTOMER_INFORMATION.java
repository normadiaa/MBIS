package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class CUSTOMER_INFORMATION extends AppCompatActivity {

    EditText NAME,PHONENUM,EMAIL,ADDRESS;
    Button SAVE,CANCEL;

    String custName;
    String custPhoneNum ;
    String custEmail;
    String custAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer__information);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        NAME = (EditText) findViewById(R.id.etCustName);
        PHONENUM = (EditText) findViewById(R.id.etCustPhoneNum);
        EMAIL = (EditText) findViewById(R.id.etCustEmail);
        ADDRESS = (EditText) findViewById(R.id.etCustAddress);
        SAVE = (Button) findViewById(R.id.btnCustSave);
        CANCEL = (Button) findViewById(R.id.btnCustCancel);

        CANCEL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(CUSTOMER_INFORMATION.this, CUSTOMER_LIST.class);
                startActivity(intent);
            }
        });

        SAVE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                custName = NAME.getText().toString().trim();
                custPhoneNum = PHONENUM.getText().toString().trim();
                custEmail = EMAIL.getText().toString().trim();
                custAddress = ADDRESS.getText().toString().trim();

                new InsertDataActivity().execute();

            }
        });

    }


    class InsertDataActivity extends AsyncTask< Void, Void, Void > {

        ProgressDialog dialog;
        int jIndex;
        int x;

        String result = null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(CUSTOMER_INFORMATION.this);
            dialog.setTitle("Hey Wait Please...");
            dialog.setMessage("Inserting Data");
            dialog.show();

        }

        @Nullable
        @Override
        protected Void doInBackground(Void...params) {
            JSONObject jsonObject = Customer_Controller.insertData(custName, custPhoneNum,custEmail,custAddress);
            Log.i(Customer_Controller.TAG, "Json obj ");

            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {

                    result = jsonObject.getString("result");

                }
            } catch (JSONException je) {
                Log.i(Customer_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();

            Intent intent = new Intent(getApplicationContext(),CUSTOMER_LIST.class);
            startActivity(intent);

        }
    }


    /*

    public void onClick(View v) {
        if(v == SAVE){
            addCustomer();
        }

    }


    private void   addCustomer() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding Customer","Please wait");

        final String custName = NAME.getText().toString().trim();
        final String custPhoneNum = PHONENUM.getText().toString().trim();
        final String custEmail = EMAIL.getText().toString().trim();
        final String custAddress = ADDRESS.getText().toString().trim();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbwmLbiLVUF-dbwGDNuVH2YL-Q1Wh8mEWzAbdcsh3D2C1Ojd0Grl/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading.dismiss();
                        Toast.makeText(CUSTOMER_INFORMATION.this,response,Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(),CUSTOMER_LIST.class);
                        startActivity(intent);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(CUSTOMER_INFORMATION.this,error.toString(),Toast.LENGTH_LONG).show();

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                //here we pass params
                params.put("action","addCustomer");

                params.put("MBIS_CustName",custName);
                params.put("MBIS_CustPhoneNum",custPhoneNum);
                params.put("MBIS_CustEmail",custEmail);
                params.put("MBIS_CustAddress",custAddress);


                return params;
            }
        };

        int socketTimeOut = 50000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(stringRequest);


    }

*/



/*
    private void addCustomer(){
        final ProgressDialog loading = ProgressDialog.show(this,"Uploading...","Please wait...",false,false);

        final String custName = NAME.getText().toString().trim();
        final String custPhoneNum = PHONENUM.getText().toString().trim();
        final String custEmail = EMAIL.getText().toString().trim();
        final String custAddress = ADDRESS.getText().toString().trim();

        //Bitmap  rbitmap = getResizedBitmap(bitmap,500);


        StringRequest stringRequest = new StringRequest(Request.Method.POST,ADD_CUSTOMER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        loading.dismiss();
                        Toast.makeText(CUSTOMER_INFORMATION.this,response,Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(CUSTOMER_INFORMATION.this,error.toString(),Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();

                params.put(KEY_ACTION,"insert");

                params.put(KEY_CUSTNAME,custName);
                params.put(KEY_CUSTPHONENUM,custPhoneNum);
                params.put(KEY_CUSTEMAIL,custEmail);
                params.put(KEY_CUSTADDRESS,custAddress);


                return params;
            }

        };

        int socketTimeout = 30000; // 30 seconds. You can change it
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);


        RequestQueue requestQueue = Volley.newRequestQueue(this);

        requestQueue.add(stringRequest);
    }

    */





}
