package alabs.gsheetwithimage;

import android.support.annotation.NonNull;
import android.util.Log;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class Product_Controller {

    public static final String TAG = "TAG";

    public static final String WAURL="https://script.google.com/macros/s/AKfycbzL1kvM_ZCq9uYtLI8rZVXAP8Eqg86ZedGIRJNDXTXtvCQU8YIA/exec?";
    // EG : https://script.google.com/macros/s/AKfycbwXXXXXXXXXXXXXXXXX/exec?
//Make Sure '?' Mark is present at the end of URL
    private static Response response;


    public static JSONObject deleteData(String MBIS_ProductBarcode) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(WAURL+"action=delete&MBIS_ProductBarcode="+MBIS_ProductBarcode)
                    .build();
            response = client.newCall(request).execute();
            // Log.e(TAG,"response from gs"+response.body().string());
            return new JSONObject(response.body().string());


        } catch (@NonNull IOException | JSONException e) {
            Log.e(TAG, "recieving null " + e.getLocalizedMessage());
        }
        return null;
    }

/* ########################################################################################################################################## */


    public static JSONObject updateData(String MBIS_ProductBarcode, String MBIS_ProductName, String MBIS_ProductQuantity, String MBIS_ProductPurchasesPrice, String MBIS_ProductSalesPrice, String MBIS_ProductInformation,String MBIS_ProductImage ) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(WAURL+"action=update&MBIS_ProductBarcode="+MBIS_ProductBarcode+"&MBIS_ProductName="+MBIS_ProductName+"&MBIS_ProductQuantity="+MBIS_ProductQuantity+"&MBIS_ProductPurchasesPrice="+MBIS_ProductPurchasesPrice+"&MBIS_ProductSalesPrice="+MBIS_ProductSalesPrice+"&MBIS_ProductInformation="+MBIS_ProductInformation+"&MBIS_ProductImage="+MBIS_ProductImage)
                    .build();
            response = client.newCall(request).execute();
            //    Log.e(TAG,"response from gs"+response.body().string());
            return new JSONObject(response.body().string());


        } catch (@NonNull IOException | JSONException e) {
            Log.e(TAG, "recieving null " + e.getLocalizedMessage());
        }
        return null;
    }


}
