package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class PURCHASE_INFORMATION extends AppCompatActivity {

    String MBIS_ProductBarcode;
    String MBIS_ProductName;
    String MBIS_ProductQuantity;
    String MBIS_ProductPurchasesPrice;
    String MBIS_ProductSalesPrice;

    EditText CurrentQuantity, AddQuantity,TotalQuantity,PurchasePrice,SalePrice,TotalPrice,Info;
    TextView ProductBarode, ProductName;
    Button CancelPurchase, SavePurchase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase__information);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        MBIS_ProductBarcode = intent.getStringExtra("MBIS_ProductBarcode");
        MBIS_ProductName = intent.getStringExtra("MBIS_ProductName");
        MBIS_ProductSalesPrice = intent.getStringExtra("MBIS_ProductSalesPrice");
        MBIS_ProductQuantity = intent.getStringExtra("MBIS_ProductQuantity");
        MBIS_ProductPurchasesPrice = intent.getStringExtra("MBIS_ProductPurchasesPrice");


        ProductBarode = (TextView)findViewById(R.id.tv_ProductBarcode);
        ProductName=(TextView)findViewById(R.id.tv_ProductName);
        CurrentQuantity = (EditText)findViewById(R.id.et_Quantity);
        AddQuantity = (EditText)findViewById(R.id.et_Sale);
        TotalQuantity = (EditText)findViewById(R.id.et_TotalQuantity);
        PurchasePrice = (EditText)findViewById(R.id.et_PurchasePrice);
        SalePrice = (EditText)findViewById(R.id.et_SalePrice);
        TotalPrice = (EditText)findViewById(R.id.et_Total);
        Info = (EditText)findViewById(R.id.et_AddInfo);
        CancelPurchase = (Button)findViewById(R.id.btnPurchaseCancel);
        SavePurchase = (Button)findViewById(R.id.btnPurchaseSave);


        ProductBarode.setText(MBIS_ProductBarcode);
        ProductName.setText(MBIS_ProductName);
        CurrentQuantity.setText(MBIS_ProductQuantity);
        PurchasePrice.setText(MBIS_ProductPurchasesPrice);
        SalePrice.setText(MBIS_ProductSalesPrice);
        TotalQuantity.setText(MBIS_ProductQuantity);


        AddQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                int addquantity = Integer.parseInt(AddQuantity.getText().toString());
                int currentquantity = Integer.parseInt(CurrentQuantity.getText().toString());

                int totalquantity = addquantity + currentquantity;
                TotalQuantity.setText(Integer.toString(totalquantity));

                Double purchaseprice =  Double.parseDouble(PurchasePrice.getText().toString());
                Double addQuantity = Double.parseDouble(AddQuantity.getText().toString());

                Double total = purchaseprice * addQuantity;
                TotalPrice.setText(total.toString());

            }
        });

        CancelPurchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(PURCHASE_INFORMATION.this, PURCHASE.class);
                startActivity(intent1);

            }
        });

        SavePurchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addPurchase();
            }
        });


    }


    private void   addPurchase() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding Purchase","Please wait");


        final String BarcodeProduct = ProductBarode.getText().toString().trim();
        final String NamePoduct = ProductName.getText().toString().trim();
        final String QuantityAdd = AddQuantity.getText().toString().trim();
        final String PriceTotal = TotalPrice.getText().toString().trim();
        final String Information = Info.getText().toString().trim();



        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbzGG5MopAa4T38KVlz48CS5boRSB1iMXCw9t0fJOUJ9W1hQ_Gee/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading.dismiss();
                        Toast.makeText(PURCHASE_INFORMATION.this,response,Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(),PURCHASE.class);
                        startActivity(intent);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(PURCHASE_INFORMATION.this,error.toString(),Toast.LENGTH_LONG).show();

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                //here we pass params
                params.put("action","addPurchase");


                params.put("MBIS_ProductBarcode",BarcodeProduct);
                params.put("MBIS_ProductName",NamePoduct);
                params.put("MBIS_PurchaseQuantity",QuantityAdd);
                params.put("MBIS_PurchaseTotal",PriceTotal);
                params.put("MBIS_PurchaseInformation",Information);



                return params;
            }
        };

        int socketTimeOut = 50000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(stringRequest);


    }




}
