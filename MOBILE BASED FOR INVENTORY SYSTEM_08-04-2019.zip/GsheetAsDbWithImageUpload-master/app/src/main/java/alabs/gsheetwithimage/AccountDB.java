package alabs.gsheetwithimage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AccountDB extends SQLiteOpenHelper {

    public static final String dbName="dbMobileBasedForInventorySystem"; //DATABASE NAME
    //public static final int DATABASE_VERSION=1; //database version

    // ****** registration table *****
    public static final String tableName="STOCKIST"; //table name
    public static final String idColumn="MBIS_StockistID";
    public static final String nameColumn="MBIS_StockistName";
    public static final String emailColumn="MBIS_StockistEmail";
    public static final String phoneColumn="MBIS_StockistPhoneNum";
    // public static final String usernameColumn="username";
    public static final String passwordColumn="MBIS_StockistPassword";
    public static final String conpasswordColumn="MBIS_StockistConfirmPassword";

    // ****** add product table *****
    public static final String product_tableName="PRODUCT"; //table name
    // public static final String product_idColumn="id";
    public static final String product_pictureColumn="MBIS _ProductPicture";
    public static final String product_codeColumn="MBIS_ProductBarcode";
    public static final String product_nameColumn="MBIS_ProductName";
    public static final String product_quantityColumn="MBIS_ProductQuantity";
    public static final String product_purchasesColumn="MBIS_ProductPurchasesPrice";
    public static final String product_SalesColumn="MBIS_ProductSalesPrice";
    public static final String productInfoColumn="MBIS_ProductInformation";


    // ****** add customer table *****
    public static final String cust_tableName="CUSTOMER"; //table name
    public static final String cust_idColumn="MBIS_CustID";
    public static final String cust_nameColumn="MBIS_CustName";
    public static final String cust_phoneNumColumn="MBIS_CustPhoneNum";
    public static final String cust_emailColumn="MBIS_CustEmail";
    public static final String cust_addressColumn="MBIS_CustAddress";


    // ****** add supplier table *****
    public static final String supp_tableName="SUPPLIER"; //table name
    public static final String supp_idColumn="MBIS_SuppID";
    public static final String supp_companyColumn="MBIS_SuppCompany";
    public static final String supp_nameColumn="MBIS_SuppName";
    public static final String supp_phoneNumColumn="MBIS_SuppPhoneNum";
    public static final String supp_emailColumn="MBIS_SuppEmail";
    public static final String supp_addressColumn="MBIS_SuppAddress";


    public AccountDB(Context context){
        super(context, dbName, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        // ***** insert database account register
        sqLiteDatabase.execSQL("create table " + tableName + "(" +
                idColumn + " integer primary key autoincrement, " +
                nameColumn + " text, " +
                emailColumn + " text, " +
                phoneColumn + " text, " +
                // usernameColumn + " text,  " +
                passwordColumn + " text,  " +
                conpasswordColumn + " text " + ")"
        );

        // ***** insert database product
        sqLiteDatabase.execSQL("create table " + product_tableName + "(" +
                //product_idColumn + " integer primary key autoincrement, " +
                product_pictureColumn + " text, " +
                product_codeColumn + " text, " +
                product_nameColumn + " text, " +
                product_quantityColumn + " integer, " +
                product_purchasesColumn + " double, " +
                product_SalesColumn + " double, " +
                productInfoColumn + " text " + ")"
        );


        // ***** insert database customer
        sqLiteDatabase.execSQL("create table " + cust_tableName + "(" +
                cust_idColumn + " integer primary key autoincrement, " +
                cust_nameColumn + " text, " +
                cust_emailColumn + " text, " +
                cust_phoneNumColumn + " text, " +
                cust_addressColumn + " text  " + ")"
        );


        // ***** insert database supplier
        sqLiteDatabase.execSQL("create table " + supp_tableName + "(" +
                supp_idColumn + " integer primary key autoincrement, " +
                supp_companyColumn + " text,  " +
                supp_nameColumn + " text, " +
                supp_phoneNumColumn + " text, " +
                supp_emailColumn + " text, " +
                supp_addressColumn + " text " + ")"
        );


    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        onCreate(sqLiteDatabase);

    }

    // ***** create database account register
    public boolean create(Account account){

        boolean result = true;
        try{
            SQLiteDatabase sqLiteDatabase = getWritableDatabase();
            ContentValues contentValues = new ContentValues();

            contentValues.put(nameColumn, account.getName());
            contentValues.put(emailColumn, account.getEmail());
            contentValues.put(phoneColumn, account.getPhonenum());
            //contentValues.put(usernameColumn, account.getUsername());
            contentValues.put(passwordColumn, account.getPassword());
            contentValues.put(conpasswordColumn, account.getConpassword());


            result = sqLiteDatabase.insert(tableName,null,contentValues) > 0;

        }catch(Exception e){
            result = false;
        }
        return result;
    }


    /*
    // ***** create database product
    public boolean createproduct(Product product){

        boolean result = true;
        try{
            SQLiteDatabase sqLiteDatabase = getWritableDatabase();
            ContentValues contentValues = new ContentValues();

            contentValues.put(product_codeColumn, product.getCode());
            contentValues.put(product_nameColumn, product.getName());
            contentValues.put(product_quantityColumn, product.getQuantity());
            contentValues.put(product_purchasesColumn, product.getPurchases());
            contentValues.put(product_SalesColumn, product.getSales());
            contentValues.put(productInfoColumn, product.getProductinfo());


            result = sqLiteDatabase.insert(product_tableName,null,contentValues) > 0;

        }catch(Exception e){
            result = false;
        }
        return result;
    }

    // ***** create database customer
    public boolean createcustomer(CustomerInfo customerInfo){

        boolean result = true;
        try{
            SQLiteDatabase sqLiteDatabase = getWritableDatabase();
            ContentValues contentValues = new ContentValues();

            contentValues.put(cust_nameColumn, customerInfo.getName());
            contentValues.put(cust_emailColumn, customerInfo.getEmail());
            contentValues.put(cust_phoneNumColumn, customerInfo.getPhonenum());
            contentValues.put(cust_addressColumn, customerInfo.getAddress());

            result = sqLiteDatabase.insert(cust_tableName,null,contentValues) > 0;

        }catch(Exception e){
            result = false;
        }
        return result;
    }

    // ***** create database supplier
    public boolean createsupplier(SupplierInfo supplierInfo){

        boolean result = true;
        try{
            SQLiteDatabase sqLiteDatabase = getWritableDatabase();
            ContentValues contentValues = new ContentValues();

            contentValues.put(supp_companyColumn, supplierInfo.getCompany());
            contentValues.put(supp_phoneNumColumn, supplierInfo.getName());
            contentValues.put(supp_nameColumn, supplierInfo.getName());
            contentValues.put(supp_emailColumn, supplierInfo.getEmail());
            contentValues.put(supp_addressColumn, supplierInfo.getAddress());

            result = sqLiteDatabase.insert(supp_tableName,null,contentValues) > 0;

        }catch(Exception e){
            result = false;
        }
        return result;
    }

    */

    // ***** check email and password for login
    public Account login(String MBIS_StockistEmail, String MBIS_StockistPassword){
        Account account = null;

        try{
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            Cursor cursor = sqLiteDatabase.rawQuery(" select * from " + tableName + " where MBIS_StockistEmail = ? and MBIS_StockistPassword = ? ", new String[] {MBIS_StockistEmail, MBIS_StockistPassword} );
            if(cursor.moveToFirst()) {

                account = new Account();

                account.setId(cursor.getInt(0));
                account.setName(cursor.getString(1));
                account.setEmail(cursor.getString(2));
                account.setPhonenum(cursor.getString(3));
                //account.setUsername(cursor.getString(4));
                account.setPassword(cursor.getString(4));
                account.setConpassword(cursor.getString(5));
            }
        }catch(Exception e){
            account = null;
        }
        return account;
    }

    // ***** check if there any registered email
    public Account checkEmail(String MBIS_StockistEmail){

        Account account = null;

        try{
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            Cursor cursor = sqLiteDatabase.rawQuery(" select * from " + tableName + " where MBIS_StockistEmail = ? ", new String[] {MBIS_StockistEmail} );
            if(cursor.moveToFirst()){
                account = new Account();

                account.setId(cursor.getInt(0));
                account.setName(cursor.getString(1));
                account.setEmail(cursor.getString(2));
                account.setPhonenum(cursor.getString(3));
                //  account.setUsername(cursor.getString(4));
                account.setPassword(cursor.getString(4));
                account.setConpassword(cursor.getString(5));
            }
        }catch(Exception e){
            account = null;
        }
        return account;
    }

    /*

    // ***** check if there any registered code of product
    public Product checkCode(String MBIS_ProductBarcode){

        Product product = null;

        try{
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            Cursor cursor = sqLiteDatabase.rawQuery(" select * from " + product_tableName + " where MBIS_ProductBarcode = ? ", new String[] {MBIS_ProductBarcode} );

            if(cursor.moveToFirst()){
                product = new Product();

                //product.setId(cursor.getInt(0));
                product.setCode(cursor.getString(0));
                product.setName(cursor.getString(1));
                product.setQuantity(cursor.getInt(2));
                product.setPurchases(cursor.getDouble(3));
                product.setSales(cursor.getDouble(4));
                product.setProductinfo(cursor.getString(5));
            }
        }catch(Exception e){
            product = null;
        }
        return product;
    }


    // ***** check if there any registered company of supplier
    public SupplierInfo checkCompany(String MBIS_SuppCompany){

        SupplierInfo supplierInfo = null;

        try{
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            Cursor cursor = sqLiteDatabase.rawQuery(" select * from " + supp_tableName + " where MBIS_SuppCompany = ? ", new String[] {MBIS_SuppCompany} );

            if(cursor.moveToFirst()){
                supplierInfo = new SupplierInfo();

                supplierInfo.setId(cursor.getInt(0));
                supplierInfo.setCompany(cursor.getString(1));
                supplierInfo.setName(cursor.getString(2));
                supplierInfo.setPhonenum(cursor.getString(3));
                supplierInfo.setEmail(cursor.getString(4));
                supplierInfo.setAddress(cursor.getString(5));
            }
        }catch(Exception e){
            supplierInfo = null;
        }
        return supplierInfo;
    }


    // ***** check if there any registered phone number of customer
    public CustomerInfo checkPhoneNum(String MBIS_CustPhoneNum){

        CustomerInfo customerInfo = null;

        try{
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            Cursor cursor = sqLiteDatabase.rawQuery(" select * from " + cust_tableName + " where MBIS_CustPhoneNum = ? ", new String[] {MBIS_CustPhoneNum} );

            if(cursor.moveToFirst()){
                customerInfo = new CustomerInfo();

                customerInfo.setId(cursor.getInt(0));
                customerInfo.setName(cursor.getString(1));
                customerInfo.setPhonenum(cursor.getString(2));
                customerInfo.setEmail(cursor.getString(3));
                customerInfo.setAddress(cursor.getString(4));
            }
        }catch(Exception e){
            customerInfo = null;
        }
        return customerInfo;
    }

    public Cursor getListContents()
    {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        Cursor data = sqLiteDatabase.rawQuery(" select * from " + product_tableName, null);
        return data;
    }

    */

    /*
    public Cursor getItemID(String name)
    {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        String query = " SELECT " + product_codeColumn + " FROM " + product_tableName + " WHERE " + product_nameColumn + " = '" + name + "'";
       Cursor data = sqLiteDatabase.rawQuery(query,null);
       return data;
    }

    public void updateName(String newName,int id, String oldName)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        String query = " UPDATE " + product_tableName + " SET " + product_nameColumn +
                " = '" + newName + "' WHERE " + product_codeColumn + " = '" + id + "'" +
                " AND " + product_nameColumn + " = '" + oldName + "'";
        Log.d(TAG, "updateName : query " + query);
        Log.d(TAG, "updateName : Setting name to " + newName);
        sqLiteDatabase.execSQL(query);
    }

    public void deleteName (int id, String name) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        String query = " DELETE FROM " + product_tableName + " WHERE " + product_codeColumn + " = '" + id + "'" +
                " AND " + product_nameColumn + " = '" + name + "'";

        Log.d(TAG, "deleteName : query " + query);
        Log.d(TAG, "deleteName : Deleting " + name + " from database ");
        sqLiteDatabase.execSQL(query);
    }

    */
    /*

    public Cursor getListCustomer()
    {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        Cursor data = sqLiteDatabase.rawQuery(" select * from " + cust_tableName,null);
        return data;
    }

    public Cursor getListSupplier()
    {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        Cursor data = sqLiteDatabase.rawQuery(" select * from " + supp_tableName,null);
        return data;
    }

    */


}

