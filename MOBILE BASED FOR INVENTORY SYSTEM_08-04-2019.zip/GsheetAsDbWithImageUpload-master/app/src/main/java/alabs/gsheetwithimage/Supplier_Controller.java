package alabs.gsheetwithimage;

import android.support.annotation.NonNull;
import android.util.Log;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class Supplier_Controller {

    public static final String TAG = "TAG";

    public static final String WAURL="https://script.google.com/macros/s/AKfycbzPZM1GYn6YY3MxwDfyYsQjcdmpLn-2Gi7x9WNGAoS2ZDhi_zQ/exec?";
    // EG : https://script.google.com/macros/s/AKfycbwXXXXXXXXXXXXXXXXX/exec?
//Make Sure '?' Mark is present at the end of URL
    private static Response response;


/* ########################################################################################################################################### */

    public static JSONObject insertData(String MBIS_SuppCompany, String MBIS_SuppName, String MBIS_SuppPhoneNum, String MBIS_SuppEmail, String MBIS_SuppAddress ) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(WAURL+"action=insert&MBIS_SuppCompany="+MBIS_SuppCompany+"&MBIS_SuppName="+MBIS_SuppName+"&MBIS_SuppPhoneNum="+MBIS_SuppPhoneNum+"&MBIS_SuppEmail="+MBIS_SuppEmail+"&MBIS_SuppAddress="+MBIS_SuppAddress)
                    .build();
            response = client.newCall(request).execute();
            //    Log.e(TAG,"response from gs"+response.body().string());
            return new JSONObject(response.body().string());


        } catch (@NonNull IOException | JSONException e) {
            Log.e(TAG, "recieving null " + e.getLocalizedMessage());
        }
        return null;
    }

/* ########################################################################################################################################### */



    public static JSONObject deleteData(String MBIS_SuppEmail) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(WAURL+"action=delete&MBIS_SuppEmail="+MBIS_SuppEmail)
                    .build();
            response = client.newCall(request).execute();
            // Log.e(TAG,"response from gs"+response.body().string());
            return new JSONObject(response.body().string());


        } catch (@NonNull IOException | JSONException e) {
            Log.e(TAG, "recieving null " + e.getLocalizedMessage());
        }
        return null;
    }

/* ########################################################################################################################################### */



    public static JSONObject updateData(String MBIS_SuppCompany, String MBIS_SuppName, String MBIS_SuppPhoneNum, String MBIS_SuppEmail, String MBIS_SuppAddress ) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(WAURL+"action=update&MBIS_SuppCompany="+MBIS_SuppCompany+"&MBIS_SuppName="+MBIS_SuppName+"&MBIS_SuppPhoneNum="+MBIS_SuppPhoneNum+"&MBIS_SuppEmail="+MBIS_SuppEmail+"&MBIS_SuppAddress="+MBIS_SuppAddress)
                    .build();
            response = client.newCall(request).execute();
            //    Log.e(TAG,"response from gs"+response.body().string());
            return new JSONObject(response.body().string());


        } catch (@NonNull IOException | JSONException e) {
            Log.e(TAG, "recieving null " + e.getLocalizedMessage());
        }
        return null;
    }



}
