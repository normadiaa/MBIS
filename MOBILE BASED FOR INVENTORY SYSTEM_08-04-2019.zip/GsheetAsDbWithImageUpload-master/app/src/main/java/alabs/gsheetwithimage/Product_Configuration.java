package alabs.gsheetwithimage;

/**
 * Created by ADJ on 8/9/2017.
 */

public class Product_Configuration {

    public static final String APP_SCRIPT_WEB_APP_URL = "https://script.google.com/macros/s/AKfycbzL1kvM_ZCq9uYtLI8rZVXAP8Eqg86ZedGIRJNDXTXtvCQU8YIA/exec";
    public static final String ADD_USER_URL = APP_SCRIPT_WEB_APP_URL;
    public static final String LIST_USER_URL = APP_SCRIPT_WEB_APP_URL+"?action=readAll";

    public static final String KEY_CODE = "MBIS_ProductBarcode";
    public static final String KEY_NAME = "MBIS_ProductName";
    public static final String KEY_QUANTITY = "MBIS_ProductQuantity";
    public static final String KEY_PURCHASESPRICE = "MBIS_ProductPurchasesPrice";
    public static final String KEY_SALESPRICE = "MBIS_ProductSalesPrice";
    public static final String KEY_INFORMATION = "MBIS_ProductInformation";
    public static final String KEY_IMAGE = "MBIS_ProductImage";

    public  static final String KEY_ACTION = "action";

    public static final String KEY_USERS = "records";




}
