package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class PRODUCT_UPDATE_DELETE extends AppCompatActivity {


    EditText CODE,NAME,QUANTITY,PURHASES,SALES,PRODUCTINFO;
    Button SAVE,DELETE,IMAGE;
    ImageView IMAGEVIEW;

    //String productImage;
    String userImage;
    private int PICK_IMAGE_REQUEST = 1;
    Bitmap rbitmap, ubmp;

    String MBIS_ProductBarcode;
    String MBIS_ProductName;
    String MBIS_ProductQuantity;
    String MBIS_ProductPurchasesPrice;
    String MBIS_ProductSalesPrice;
    String MBIS_ProductInformation;
    String MBIS_ProductImage;

    String ProductBarcode;
    String ProductName;
    String ProductQuantity;
    String ProductPurchasesPrice;
    String ProductSalesPrice;
    String ProductInformation;
    String ProductImage;

    String deletebycode;
    String productImage;
    String bmp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product__update__delete);


        Intent intent = getIntent();
        MBIS_ProductBarcode = intent.getStringExtra("MBIS_ProductBarcode");
        MBIS_ProductName = intent.getStringExtra("MBIS_ProductName");
        MBIS_ProductQuantity = intent.getStringExtra("MBIS_ProductQuantity");
        MBIS_ProductPurchasesPrice = intent.getStringExtra("MBIS_ProductPurchasesPrice");
        MBIS_ProductSalesPrice = intent.getStringExtra("MBIS_ProductSalesPrice");
        MBIS_ProductInformation = intent.getStringExtra("MBIS_ProductInformation");
        MBIS_ProductImage = intent.getStringExtra("MBIS_ProductImage");


       // IMAGEVIEW.setImageBitmap(MBIS_ProductImage);


        CODE = (EditText) findViewById(R.id.etCode);
        NAME = (EditText) findViewById(R.id.etName);
        QUANTITY = (EditText) findViewById(R.id.etQuantity);
        PURHASES = (EditText) findViewById(R.id.etPurcahses);
        SALES = (EditText) findViewById(R.id.etSales);
        PRODUCTINFO = (EditText) findViewById(R.id.etProductInfo);

        SAVE = (Button) findViewById(R.id.btnSave);
        DELETE = (Button) findViewById(R.id.btnDelete);
        IMAGE = (Button) findViewById(R.id.btnCamera);
        IMAGEVIEW = (ImageView) findViewById(R.id.imageCamera);

        CODE.setText(MBIS_ProductBarcode);
        NAME.setText(MBIS_ProductName);
        QUANTITY.setText(MBIS_ProductQuantity);
        PURHASES.setText(MBIS_ProductPurchasesPrice);
        SALES.setText(MBIS_ProductSalesPrice);
        PRODUCTINFO.setText(MBIS_ProductInformation);

        Picasso.with(this).load(MBIS_ProductImage).into(IMAGEVIEW);

        /*
        Picasso.with(this).load(MBIS_ProductImage).into(new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {

                IMAGEVIEW.setImageBitmap(bitmap);

                ubmp = getResizedBitmap(bitmap,250);



                }

                @Override
                public void onBitmapFailed(Drawable errorDrawable) {

                }

                @Override
                public void onPrepareLoad(Drawable placeHolderDrawable) {

                }
                });
                */




                DELETE.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        deletebycode = CODE.getText().toString();

                        new DeleteDataActivity().execute();


                    }
                });


        SAVE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ProductBarcode = CODE.getText().toString();
                ProductName = NAME.getText().toString();
                ProductQuantity = QUANTITY.getText().toString();
                ProductPurchasesPrice = PURHASES.getText().toString();
                ProductSalesPrice = SALES.getText().toString();
                ProductInformation = PRODUCTINFO.getText().toString();


               // Log.e("null","values"+bmp);

                //ProductImage = IMAGEVIEW.getText().toString();

               //ProductImage = bmp;
                //IMAGEVIEW.setImageBitmap(rbitmap);

                 //ProductImage = getStringImage( ( (BitmapDrawable) IMAGEVIEW.getDrawable( ) ).getBitmap() );

                Bitmap picbitmap = ((BitmapDrawable)IMAGEVIEW.getDrawable()).getBitmap();
                //ubmp = getResizedBitmap(picbitmap,250); //Setting the Bitmap to ImageView
                ProductImage = getStringImage(picbitmap);






               new UpdateDataActivity().execute();

            }
        });


        IMAGE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showFileChooser();

            }
        });


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    }

/* ######################################################################################################################################################### */


    class DeleteDataActivity extends AsyncTask<Void, Void, Void>
        {
        ProgressDialog dialog;
        int jIndex;
        int x;
        String result=null;



        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(PRODUCT_UPDATE_DELETE.this);
            dialog.setTitle("Hey Wait Please...");
            dialog.setMessage("Deleting... ");
            dialog.show();

        }

        @Nullable
        @Override
        protected Void doInBackground(Void... params) {
            Log.i(Product_Controller.TAG,"MBIS_ProductBarcode"+deletebycode);
            JSONObject jsonObject = Product_Controller.deleteData(deletebycode);
            Log.i(Product_Controller.TAG, "Json obj "+jsonObject);

            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {

                    result=jsonObject.getString("result");


                }
            } catch (JSONException je) {
                Log.i(Product_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            Toast.makeText(PRODUCT_UPDATE_DELETE.this,result,Toast.LENGTH_LONG).show();


            // Toast.makeText(CUSTOMER_INFORMATION.this,response,Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(),PRODUCT_LIST.class);
            startActivity(intent);


        }
    }

/* ####################################################################################################################################################### */



    class UpdateDataActivity extends AsyncTask<Void, Void, Void> {

        ProgressDialog dialog;
        int jIndex;
        int x;

        String result=null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(PRODUCT_UPDATE_DELETE.this);
            dialog.setTitle("Hey Wait Please..."+x);
            dialog.setMessage("I am getting your JSON");
            dialog.show();

        }

        @Nullable
        @Override
        protected Void doInBackground(Void... params) {
            JSONObject jsonObject = Product_Controller.updateData(ProductBarcode,ProductName,ProductQuantity,ProductPurchasesPrice,ProductSalesPrice,
                    ProductInformation, ProductImage);
            Log.i(Product_Controller.TAG, "Json obj ");

            try {

                 //Check Whether Its NULL???

                if (jsonObject != null) {

                    result=jsonObject.getString("result");

                }
            } catch (JSONException je) {
                Log.i(Product_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(getApplicationContext(),PRODUCT_LIST.class);
            startActivity(intent);

        }
    }




    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                //Getting the Bitmap from Gallery
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                rbitmap = getResizedBitmap(bitmap,250);//Setting the Bitmap to ImageView
                productImage = getStringImage(rbitmap);
                IMAGEVIEW.setImageBitmap(rbitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);

    }


    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

        return encodedImage;
    }




/* ########################################################################################################################################################### */



}
