package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class SUPPLIER_INFORMATION extends AppCompatActivity  {

    EditText COMPANY,NAME,EMAIL,ADDRESS,PHONENUM;
    Button SAVE,CANCEL;

     String suppCompany ;
     String suppName;
     String suppPhoneNum ;
     String suppEmail ;
     String suppAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplier__information);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        COMPANY = (EditText) findViewById(R.id.etSuppCompany);
        NAME = (EditText) findViewById(R.id.etSuppName);
        PHONENUM = (EditText) findViewById(R.id.etSuppPhoneNum);
        EMAIL = (EditText) findViewById(R.id.etSuppEmail);
        ADDRESS = (EditText) findViewById(R.id.etSuppAddress);
        SAVE = (Button) findViewById(R.id.btnSuppSave);
        CANCEL = (Button) findViewById(R.id.btnSuppCancel);

        CANCEL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SUPPLIER_INFORMATION.this, SUPPLIER_LIST.class);
                startActivity(intent);
            }
        });

        SAVE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                 suppCompany = COMPANY.getText().toString().trim();
                 suppName = NAME.getText().toString().trim();
                 suppPhoneNum = PHONENUM.getText().toString().trim();
                 suppEmail = EMAIL.getText().toString().trim();
                 suppAddress = ADDRESS.getText().toString().trim();

                 new InsertDataActivity().execute();

            }
        });





    }


    class InsertDataActivity extends AsyncTask< Void, Void, Void > {

        ProgressDialog dialog;
        int jIndex;
        int x;

        String result = null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(SUPPLIER_INFORMATION.this);
            dialog.setTitle("Hey Wait Please...");
            dialog.setMessage("Inserting Data");
            dialog.show();

        }

        @Nullable
        @Override
        protected Void doInBackground(Void...params) {
            JSONObject jsonObject = Supplier_Controller.insertData(suppCompany, suppName,suppPhoneNum,suppEmail,suppAddress);
            Log.i(Supplier_Controller.TAG, "Json obj ");

            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {

                    result = jsonObject.getString("result");

                }
            } catch (JSONException je) {
                Log.i(Supplier_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();

            Intent intent = new Intent(getApplicationContext(),SUPPLIER_LIST.class);
            startActivity(intent);

        }
    }



    /*

     @Override
    public void onClick(View v) {
        if(v == SAVE){
            addSupplier();
        }

    }

    private void   addSupplier() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding Supplier","Please wait");

        final String suppCompany = COMPANY.getText().toString().trim();
        final String suppName = NAME.getText().toString().trim();
        final String suppPhoneNum = PHONENUM.getText().toString().trim();
        final String suppEmail = EMAIL.getText().toString().trim();
        final String suppAddress = ADDRESS.getText().toString().trim();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbzPZM1GYn6YY3MxwDfyYsQjcdmpLn-2Gi7x9WNGAoS2ZDhi_zQ/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading.dismiss();
                        Toast.makeText(SUPPLIER_INFORMATION.this,response,Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(),SUPPLIER_LIST.class);
                        startActivity(intent);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SUPPLIER_INFORMATION.this,error.toString(),Toast.LENGTH_LONG).show();

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                //here we pass params
                params.put("action","addSupplier");

                params.put("MBIS_SuppCompany",suppCompany);
                params.put("MBIS_SuppName",suppName);
                params.put("MBIS_SuppPhoneNum",suppPhoneNum);
                params.put("MBIS_SuppEmail",suppEmail);
                params.put("MBIS_SuppAddress",suppAddress);


                return params;
            }
        };

        int socketTimeOut = 50000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(stringRequest);


    }

*/



/*
    private void addSupplier(){
        final ProgressDialog loading = ProgressDialog.show(this,"Uploading...","Please wait...",false,false);

        final String suppCompany = COMPANY.getText().toString().trim();
        final String suppName = NAME.getText().toString().trim();
        final String suppPhoneNum = PHONENUM.getText().toString().trim();
        final String suppEmail = EMAIL.getText().toString().trim();
        final String suppAddress = ADDRESS.getText().toString().trim();

        //Bitmap  rbitmap = getResizedBitmap(bitmap,500);


        StringRequest stringRequest = new StringRequest(Request.Method.POST,ADD_SUPPLIER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        loading.dismiss();
                        Toast.makeText(SUPPLIER_INFORMATION.this,response,Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SUPPLIER_INFORMATION.this,error.toString(),Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();

                params.put(KEY_SUPPACTION,"insert");

                params.put(KEY_SUPPCOMPANY,suppCompany);
                params.put(KEY_SUPPNAME,suppName);
                params.put(KEY_SUPPPHONENUM,suppPhoneNum);
                params.put(KEY_SUPPEMAIL,suppEmail);
                params.put(KEY_SUPPADDRESS,suppAddress);


                return params;
            }

        };

        int socketTimeout = 30000; // 30 seconds. You can change it
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);


        RequestQueue requestQueue = Volley.newRequestQueue(this);

        requestQueue.add(stringRequest);
    }
*/


}
