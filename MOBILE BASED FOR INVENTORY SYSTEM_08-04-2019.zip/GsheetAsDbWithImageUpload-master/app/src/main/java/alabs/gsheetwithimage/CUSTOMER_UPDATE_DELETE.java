package alabs.gsheetwithimage;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class CUSTOMER_UPDATE_DELETE extends AppCompatActivity {

    private static final int REQUEST_CALL =1;

    String MBIS_CustEmail;
    String MBIS_CustName;
    String MBIS_CustPhoneNum;
    String MBIS_CustAddress;

    String CustEmail;
    String CustName;
    String CustPhoneNum;
    String CustAddress;

    String deletebyemail;

    EditText Name, PhoneNum, Email, Address;
    Button Delete, Update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer__update__delete);

        Intent intent = getIntent();
        MBIS_CustName = intent.getStringExtra("MBIS_CustName");
        MBIS_CustPhoneNum = intent.getStringExtra("MBIS_CustPhoneNum");
        MBIS_CustEmail = intent.getStringExtra("MBIS_CustEmail");
        MBIS_CustAddress = intent.getStringExtra("MBIS_CustAddress");

        Name = (EditText)findViewById(R.id.etCustName);
        PhoneNum = (EditText)findViewById(R.id.etCustPhoneNum);
        Email = (EditText)findViewById(R.id.etCustEmail);
        Address = (EditText)findViewById(R.id.etCustAddress);
        Delete = (Button)findViewById(R.id.btnCustDelete);
        Update = (Button)findViewById(R.id.btnCustSave);
        ImageView Call = (ImageView)findViewById(R.id.iv_CustPhoneNum);
        ImageView SendEmail = (ImageView)findViewById(R.id.iv_CustEmail);


        Name.setText(MBIS_CustName);
        PhoneNum.setText("0"+MBIS_CustPhoneNum);
        Email.setText(MBIS_CustEmail);
        Address.setText(MBIS_CustAddress);


        Call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });

        SendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail();
            }
        });

        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deletebyemail=Email.getText().toString();

                new DeleteDataActivity().execute();

            }
        });


        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                CustEmail = Email.getText().toString();
                CustName = Name.getText().toString();
                CustPhoneNum = PhoneNum.getText().toString();
                CustAddress = Address.getText().toString();


                new UpdateDataActivity().execute();


                // new UpdateDataActivity().execute();

            }
        });




        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

       // new ReadData().execute();


    }



    /* ########################################################################################################################################### */

    private void makePhoneCall() {
        String number = PhoneNum.getText().toString();
        if (number.trim().length() > 0) {

            if (ContextCompat.checkSelfPermission(CUSTOMER_UPDATE_DELETE.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(CUSTOMER_UPDATE_DELETE.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }

        } else {
            Toast.makeText(CUSTOMER_UPDATE_DELETE.this, "Enter Phone Number", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }


/* ########################################################################################################################################## */

    private void sendEmail(){

        String recipient = Email.getText().toString();
        String[] recipients = recipient.split(",");

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL,recipients);

        intent.setType("message");
        startActivity(Intent.createChooser(intent,"Choose an email client"));
    }


/* ########################################################################################################################################## */


    class DeleteDataActivity extends AsyncTask<Void, Void, Void> {

        ProgressDialog dialog;
        int jIndex;
        int x;
        String result=null;



        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(CUSTOMER_UPDATE_DELETE.this);
            dialog.setTitle("Hey Wait Please...");
            dialog.setMessage("Deleting... ");
            dialog.show();

        }

        @Nullable
        @Override
        protected Void doInBackground(Void... params) {
            Log.i(Customer_Controller.TAG,"MBIS_CustEmail"+deletebyemail);
            JSONObject jsonObject = Customer_Controller.deleteData(deletebyemail);
            Log.i(Customer_Controller.TAG, "Json obj "+jsonObject);

            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {

                    result=jsonObject.getString("result");


                }
            } catch (JSONException je) {
                Log.i(Customer_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
           Toast.makeText(CUSTOMER_UPDATE_DELETE.this,result,Toast.LENGTH_LONG).show();


           // Toast.makeText(CUSTOMER_INFORMATION.this,response,Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(),CUSTOMER_LIST.class);
            startActivity(intent);


        }
    }

/* ########################################################################################################################################## */




    class UpdateDataActivity extends AsyncTask<Void, Void, Void> {

        ProgressDialog dialog;
        int jIndex;
        int x;

        String result=null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(CUSTOMER_UPDATE_DELETE.this);
            dialog.setTitle("Hey Wait Please..."+x);
            dialog.setMessage("I am getting your JSON");
            dialog.show();

        }



        @Nullable
        @Override
        protected Void doInBackground(Void... params) {
            JSONObject jsonObject = Customer_Controller.updateData(CustEmail,CustName,CustPhoneNum,CustAddress);
            Log.i(Customer_Controller.TAG, "Json obj ");

            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {

                    result=jsonObject.getString("result");

                }
            } catch (JSONException je) {
                Log.i(Customer_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(getApplicationContext(),CUSTOMER_LIST.class);
            startActivity(intent);

        }
    }

/* ########################################################################################################################################### */


    /*

    class ReadData extends AsyncTask<Void, Void, Void>{

        ProgressDialog dialog;
        int jIndex;
        int x;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(CUSTOMER_UPDATE_DELETE.this);
            dialog.setTitle("Hey Wait Please...");
            dialog.setMessage("Fetching your values");
            dialog.show();

        }

        @Override
        protected Void doInBackground(Void...params) {
            Log.i(Customer_Controller.TAG, "MBIS_CustEmail" + MBIS_CustEmail);
            JSONObject jsonObject = Customer_Controller.readData(MBIS_CustEmail);
            Log.i(Customer_Controller.TAG, "Json obj " + jsonObject);

            try {

                 //Check Whether Its NULL???

                if (jsonObject != null) {

                    //JSONObject user = jsonObject.getJSONObject("user");
                   // name = user.getString("name");

                    JSONObject customer = jsonObject.getJSONObject("user");

                     MBIS_CustName = customer.getString("MBIS_CustName");
                     MBIS_CustPhoneNum = customer.getString("MBIS_CustPhoneNum");
                     MBIS_CustEmail = customer.getString("MBIS_CustEmail");
                     MBIS_CustAddress = customer.getString("MBIS_CustAddress");


                }
            } catch (JSONException je) {
                Log.i(Customer_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            if (MBIS_CustEmail != null) {
                Name.setText(MBIS_CustName);
                PhoneNum.setText(MBIS_CustPhoneNum);
                Email.setText(MBIS_CustEmail);
                Address.setText(MBIS_CustAddress);


            } else
                Toast.makeText(getApplicationContext(), "ID not found", Toast.LENGTH_LONG).show();
        }


    }
    */


}
