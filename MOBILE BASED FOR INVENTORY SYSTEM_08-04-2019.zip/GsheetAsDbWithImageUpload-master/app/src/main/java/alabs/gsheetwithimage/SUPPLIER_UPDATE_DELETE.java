package alabs.gsheetwithimage;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class SUPPLIER_UPDATE_DELETE extends AppCompatActivity {

    private static final int REQUEST_CALL =1;



    String MBIS_SuppCompany;
    String MBIS_SuppName;
    String MBIS_SuppPhoneNum;
    String MBIS_SuppEmail;
    String MBIS_SuppAddress;

    String SuppCompany;
    String SuppName;
    String SuppPhoneNum;
    String SuppEmail;
    String SuppAddress;

    String deletebyemail;

    EditText Company, Name, PhoneNum, Email, Address;
    Button Delete, Update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplier__update__delete);


        Intent intent = getIntent();
        MBIS_SuppCompany = intent.getStringExtra("MBIS_SuppCompany");
        MBIS_SuppName = intent.getStringExtra("MBIS_SuppName");
        MBIS_SuppPhoneNum = intent.getStringExtra("MBIS_SuppPhoneNum");
        MBIS_SuppEmail = intent.getStringExtra("MBIS_SuppEmail");
        MBIS_SuppAddress = intent.getStringExtra("MBIS_SuppAddress");

        Company = (EditText)findViewById(R.id.etSuppCompany);
        Name = (EditText)findViewById(R.id.etSuppName);
        PhoneNum = (EditText)findViewById(R.id.etSuppPhoneNum);
        Email = (EditText)findViewById(R.id.etSuppEmail);
        Address = (EditText)findViewById(R.id.etSuppAddress);
        Delete = (Button)findViewById(R.id.btnSuppCancel);
        Update = (Button)findViewById(R.id.btnSuppSave);
        ImageView Call = (ImageView)findViewById(R.id.iv_SuppPhoneNum);
        ImageView SendEmail = (ImageView)findViewById(R.id.iv_SuppEmail);

        Company.setText(MBIS_SuppCompany);
        Name.setText(MBIS_SuppName);
        PhoneNum.setText("0"+MBIS_SuppPhoneNum);
        Email.setText(MBIS_SuppEmail);
        Address.setText(MBIS_SuppAddress);


        Call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });

        SendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendEmail();

            }
        });




        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deletebyemail=Email.getText().toString();

                new DeleteDataActivity().execute();

            }
        });


        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                SuppCompany = Company.getText().toString();
                SuppName = Name.getText().toString();
                SuppPhoneNum = PhoneNum.getText().toString();
                SuppEmail = Email.getText().toString();
                SuppAddress = Address.getText().toString();

                new UpdateDataActivity().execute();

                // new UpdateDataActivity().execute();

            }
        });


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



    }


/* ########################################################################################################################################### */

    private void makePhoneCall() {
        String number = PhoneNum.getText().toString();
        if (number.trim().length() > 0) {

            if (ContextCompat.checkSelfPermission(SUPPLIER_UPDATE_DELETE.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(SUPPLIER_UPDATE_DELETE.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }

        } else {
            Toast.makeText(SUPPLIER_UPDATE_DELETE.this, "Enter Phone Number", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }


/* ########################################################################################################################################### */

    private void sendEmail(){

        String recipient = Email.getText().toString();
        //String[] recipients = recipient.split(",");

        Intent intent=new Intent(Intent.ACTION_SEND);

        intent.setData(Uri.parse("mailto:"));
        intent.setType("message");

        intent.putExtra(Intent.EXTRA_EMAIL,recipient);
        intent.putExtra(Intent.EXTRA_SUBJECT,"");
        intent.putExtra(Intent.EXTRA_TEXT,"");

        try{
            startActivity(Intent.createChooser(intent,"Send Mail"));
            finish();
            Log.i("Finished sending Email","");
        }catch (android.content.ActivityNotFoundException ex){
            Toast.makeText(SUPPLIER_UPDATE_DELETE.this, "There is no email client installed",Toast.LENGTH_SHORT).show();
        }
    }

/* ########################################################################################################################################### */

    class DeleteDataActivity extends AsyncTask<Void, Void, Void> {

        ProgressDialog dialog;
        int jIndex;
        int x;
        String result=null;



        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(SUPPLIER_UPDATE_DELETE.this);
            dialog.setTitle("Hey Wait Please...");
            dialog.setMessage("Deleting... ");
            dialog.show();

        }

        @Nullable
        @Override
        protected Void doInBackground(Void... params) {
            Log.i(Supplier_Controller.TAG,"MBIS_SuppEmail"+deletebyemail);
            JSONObject jsonObject = Supplier_Controller.deleteData(deletebyemail);
            Log.i(Supplier_Controller.TAG, "Json obj "+jsonObject);

            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {

                    result=jsonObject.getString("result");


                }
            } catch (JSONException je) {
                Log.i(Supplier_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            Toast.makeText(SUPPLIER_UPDATE_DELETE.this,result,Toast.LENGTH_SHORT).show();


            // Toast.makeText(CUSTOMER_INFORMATION.this,response,Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(),SUPPLIER_LIST.class);
            startActivity(intent);


        }
    }
/* ############################################################################################################################################################################ */




    class UpdateDataActivity extends AsyncTask<Void, Void, Void> {

        ProgressDialog dialog;
        int jIndex;
        int x;

        String result=null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog = new ProgressDialog(SUPPLIER_UPDATE_DELETE.this);
            dialog.setTitle("Hey Wait Please..."+x);
            dialog.setMessage("I am getting your JSON");
            dialog.show();

        }



        @Nullable
        @Override
        protected Void doInBackground(Void... params) {
            JSONObject jsonObject = Supplier_Controller.updateData(SuppCompany,SuppName,SuppPhoneNum,SuppEmail,SuppAddress);
            Log.i(Supplier_Controller.TAG, "Json obj ");

            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {

                    result=jsonObject.getString("result");

                }
            } catch (JSONException je) {
                Log.i(Supplier_Controller.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(getApplicationContext(),SUPPLIER_LIST.class);
            startActivity(intent);

        }
    }
}
