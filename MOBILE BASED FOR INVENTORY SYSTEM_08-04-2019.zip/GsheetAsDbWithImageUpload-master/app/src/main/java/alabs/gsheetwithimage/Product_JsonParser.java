package alabs.gsheetwithimage;

/**
 * Created by ADJ on 8/9/2017.
 */

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//import static alabs.gsheetwithimage.Product_Configuration.KEY_ID;
import static alabs.gsheetwithimage.Product_Configuration.KEY_CODE;
import static alabs.gsheetwithimage.Product_Configuration.KEY_IMAGE;
import static alabs.gsheetwithimage.Product_Configuration.KEY_INFORMATION;
import static alabs.gsheetwithimage.Product_Configuration.KEY_NAME;
import static alabs.gsheetwithimage.Product_Configuration.KEY_PURCHASESPRICE;
import static alabs.gsheetwithimage.Product_Configuration.KEY_QUANTITY;
import static alabs.gsheetwithimage.Product_Configuration.KEY_SALESPRICE;
import static alabs.gsheetwithimage.Product_Configuration.KEY_USERS;


public class Product_JsonParser {
    public static String[] MBIS_ProductBarcode;
    public static String[] MBIS_ProductName;
    public static String[] MBIS_ProductQuantity;
    public static String[] MBIS_ProductPurchasesPrice;
    public static String[] MBIS_ProductSalesPrice;
    public static String[] MBIS_ProductInformation;
    public static String[] MBIS_ProductImage;


    private JSONArray product = null;

    private String json;

    public Product_JsonParser(String json){
        this.json = json;
    }

    protected void parseJSON(){
        JSONObject jsonObject=null;
        try {
            jsonObject = new JSONObject(json);
            product = jsonObject.getJSONArray(KEY_USERS);

            MBIS_ProductBarcode = new String[product.length()];
            MBIS_ProductName = new String[product.length()];
            MBIS_ProductQuantity = new String[product.length()];
            MBIS_ProductPurchasesPrice = new String[product.length()];
            MBIS_ProductSalesPrice = new String[product.length()];
            MBIS_ProductInformation = new String[product.length()];
            MBIS_ProductImage = new String[product.length()];

            for(int i=0;i<product.length();i++){
                JSONObject jo = product.getJSONObject(i);

                MBIS_ProductBarcode[i] = jo.getString(KEY_CODE);
                MBIS_ProductName[i] = jo.getString(KEY_NAME);
                MBIS_ProductQuantity[i] = jo.getString(KEY_QUANTITY);
                MBIS_ProductPurchasesPrice[i] = jo.getString(KEY_PURCHASESPRICE);
                MBIS_ProductSalesPrice[i] = jo.getString(KEY_SALESPRICE);
                MBIS_ProductInformation[i] = jo.getString(KEY_INFORMATION);
                MBIS_ProductImage[i] = jo.getString(KEY_IMAGE);
            }

           // Log.e("uImage","ser image"+uImages[0]);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
