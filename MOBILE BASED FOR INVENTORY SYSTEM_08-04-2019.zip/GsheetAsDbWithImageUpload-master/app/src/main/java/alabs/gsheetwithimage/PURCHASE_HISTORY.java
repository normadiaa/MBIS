package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class PURCHASE_HISTORY extends AppCompatActivity {

    ListAdapter adapter;
    ProgressDialog loading;
    Button Cancel, Save;
    ListView lv_PurchaseHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase__history);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Cancel = (Button)findViewById(R.id.btnPurchaseHisCancel);
        Save = (Button)findViewById(R.id.btnPurchaseHisSave);
        lv_PurchaseHistory = (ListView)findViewById(R.id.lv_PurchaseHistory);

        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PURCHASE_HISTORY.this, PURCHASE.class);
                startActivity(intent);
            }
        });

        getPurchaseHistory();

    }

/* ############################################################################################################################################ */


    private void getPurchaseHistory() {

        loading = ProgressDialog.show(this, "Loading", "please wait", false, true);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://script.google.com/macros/s/AKfycbzGG5MopAa4T38KVlz48CS5boRSB1iMXCw9t0fJOUJ9W1hQ_Gee/exec?action=getPurchase",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(PURCHASE_HISTORY.this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }


    private void parseItems (String jsonResposnce) {

        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            JSONObject jobj = new JSONObject(jsonResposnce);
            JSONArray jarray = jobj.getJSONArray("items");


            for (int i = 0; i < jarray.length(); i++) {

                JSONObject jo = jarray.getJSONObject(i);



                String MBIS_PurchaseDate = jo.getString("MBIS_PurchaseDate");
                String MBIS_ProductName = jo.getString("MBIS_ProductName");
                //Cliet Namee...
                String MBIS_PurchaseQuantity = jo.getString("MBIS_PurchaseQuantity");
                String MBIS_PurchaseTotal = jo.getString("MBIS_PurchaseTotal");
                String MBIS_PurchaseInformation = jo.getString("MBIS_PurchaseInformation");



                HashMap<String, String> item = new HashMap<>();

                item.put("MBIS_PurchaseDate", MBIS_PurchaseDate);
                item.put("MBIS_ProductName",MBIS_ProductName);
                //Cliet Namee...
                item.put("MBIS_PurchaseQuantity", MBIS_PurchaseQuantity);
                item.put("MBIS_PurchaseTotal", MBIS_PurchaseTotal);
                item.put("MBIS_PurchaseInformation",MBIS_PurchaseInformation);




                list.add(item);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapter = new SimpleAdapter(this,list,R.layout.purchaselist_row,
                new String[]{"MBIS_PurchaseQuantity", "MBIS_PurchaseDate", "MBIS_ProductName", "MBIS_PurchaseInformation", "MBIS_PurchaseTotal"},
                new int[]{R.id.tv_PurchaseQuantity, R.id.tv_PurchaseDate, R.id.tv_PurchaseProductName, R.id.tv_PurchaseInfo, R.id.tv_TotalPurchase});


        lv_PurchaseHistory.setAdapter(adapter);


        loading.dismiss();
    }



}
