package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class SALE_HISTORY extends AppCompatActivity {

    ListAdapter adapter;
    ProgressDialog loading;
    Button Cancel, Save;
    ListView lv_SaleHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sale__history);

       Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
       setSupportActionBar(toolbar);

       Cancel = (Button)findViewById(R.id.btnSaleHisCancel);
       Save = (Button)findViewById(R.id.btnSaleHisSave);
        lv_SaleHistory = (ListView)findViewById(R.id.lv_SaleHistory);

        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(SALE_HISTORY.this, SALE.class);
                startActivity(intent);
            }
        });

        getSaleHistory();



    }


/* ####################################################################################################################################################### */


    private void getSaleHistory() {

        loading = ProgressDialog.show(this, "Loading", "please wait", false, true);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://script.google.com/macros/s/AKfycbw2o-XeEVc7finPwA-GYuXxlG0XAr1SobSdvpFGHG5FcCWR8vM/exec?action=getSale",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseItems(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SALE_HISTORY.this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }
        );

        int socketTimeOut = 50000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    private void parseItems (String jsonResposnce) {

        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            JSONObject jobj = new JSONObject(jsonResposnce);
            JSONArray jarray = jobj.getJSONArray("items");


            for (int i = 0; i < jarray.length(); i++) {

                JSONObject jo = jarray.getJSONObject(i);


                String MBIS_SaleQuantity = jo.getString("MBIS_SaleQuantity");
                String MBIS_SaleDate = jo.getString("MBIS_SaleDate");
                String MBIS_ProductName = jo.getString("MBIS_ProductName");
                //Cliet Namee...
                String MBIS_SaleDescription = jo.getString("MBIS_SaleDescription");
                String MBIS_SaleType = jo.getString("MBIS_SaleType");
                String MBIS_SaleTotal = jo.getString("MBIS_SaleTotal");



                HashMap<String, String> item = new HashMap<>();
                item.put("MBIS_SaleQuantity", MBIS_SaleQuantity);
                item.put("MBIS_SaleDate", MBIS_SaleDate);
                item.put("MBIS_ProductName",MBIS_ProductName);
                //Cliet Namee...
                item.put("MBIS_SaleDescription",MBIS_SaleDescription);
                item.put("MBIS_SaleType", MBIS_SaleType);
                item.put("MBIS_SaleTotal",MBIS_SaleTotal);



                list.add(item);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapter = new SimpleAdapter(this,list,R.layout.salelist_row,
                new String[]{"MBIS_SaleQuantity", "MBIS_SaleDate", "MBIS_ProductName", "MBIS_SaleDescription", "MBIS_SaleType", "MBIS_SaleTotal"},
                new int[]{R.id.tv_Quantity, R.id.tv_SaleDate, R.id.tv_ProductName, R.id.tv_Info, R.id.tv_Type, R.id.tv_TotalSale});


        lv_SaleHistory.setAdapter(adapter);


        loading.dismiss();
    }

/* ####################################################################################################################################################### */





}
