package alabs.gsheetwithimage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class SALE_INFORMATION extends AppCompatActivity {

    String MBIS_ProductName;
    String MBIS_ProductSalesPrice;
    String MBIS_ProductBarcode;

    TextView ProductName, ProductBarode;
    EditText QUANTITY,SALEPRICE,TOTALSALE,CLIENTNAME,SALEINFO;
    RadioButton PAID,RECEIVABLE,saletype;
    Button CancelSale, SaveSale;
    RadioGroup radioGroup;

    String SALETYPE;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sale__information);


        Intent intent = getIntent();
        MBIS_ProductBarcode = intent.getStringExtra("MBIS_ProductBarcode");
        MBIS_ProductName = intent.getStringExtra("MBIS_ProductName");
        MBIS_ProductSalesPrice = intent.getStringExtra("MBIS_ProductSalesPrice");


        ProductBarode = (TextView)findViewById(R.id.tv_ProductBarcode);
        ProductName=(TextView)findViewById(R.id.tv_ProductName);
        QUANTITY = (EditText)findViewById(R.id.et_Quantity);
        QUANTITY.setSelection(0);
        SALEPRICE = (EditText)findViewById(R.id.et_Sale);
        TOTALSALE = (EditText)findViewById(R.id.et_TotalQuantity);
        CLIENTNAME = (EditText)findViewById(R.id.et_ClientName);
        SALEINFO = (EditText)findViewById(R.id.et_AddInfo);
        PAID = (RadioButton)findViewById(R.id.rb_Paid);
        RECEIVABLE = (RadioButton)findViewById(R.id.rb_Receivable);
        CancelSale = (Button)findViewById(R.id.btnSaleCancel);
        SaveSale = (Button)findViewById(R.id.btnSaleSave);
        radioGroup =(RadioGroup)findViewById(R.id.radioGroup);

        ProductBarode.setText(MBIS_ProductBarcode);
        ProductName.setText(MBIS_ProductName);
        SALEPRICE.setText(MBIS_ProductSalesPrice);


        QUANTITY.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                Double quantity = Double.parseDouble(QUANTITY.getText().toString());
                Double price = Double.parseDouble(SALEPRICE.getText().toString());

                Double total = quantity * price;
                TOTALSALE.setText(total.toString());

            }
        });


        CancelSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(SALE_INFORMATION.this, SALE.class);
                startActivity(intent1);
            }
        });



        SaveSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addSale();

            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }


    private void   addSale() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding Sale","Please wait");

        final String SaleType;

        if (PAID.isChecked()){
            SaleType=PAID.getText().toString();
        }else {
            SaleType=RECEIVABLE.getText().toString();
        }

        final String BarcodeProduct = ProductBarode.getText().toString().trim();
        final String NamePoduct = ProductName.getText().toString().trim();
        final String SaleQuantity = QUANTITY.getText().toString().trim();
       // final String SalePrice = SALEPRICE.getText().toString().trim();
        final String SaleTotal = TOTALSALE.getText().toString().trim();
        final String SaleInfo = SALEINFO.getText().toString().trim();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbw2o-XeEVc7finPwA-GYuXxlG0XAr1SobSdvpFGHG5FcCWR8vM/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading.dismiss();
                        Toast.makeText(SALE_INFORMATION.this,response,Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(),SALE.class);
                        startActivity(intent);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SALE_INFORMATION.this,error.toString(),Toast.LENGTH_LONG).show();

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                //here we pass params
                params.put("action","addSale");


                params.put("MBIS_ProductBarcode",BarcodeProduct);
                params.put("MBIS_ProductName",NamePoduct);
                params.put("MBIS_SaleQuantity",SaleQuantity);
               // params.put("MBIS_SalePrice",SalePrice);
                params.put("MBIS_SaleTotal",SaleTotal);
                params.put("MBIS_SaleType",SaleType);
                params.put("MBIS_SaleDescription",SaleInfo);


                return params;
            }
        };

        int socketTimeOut = 50000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(stringRequest);


    }


}
