package alabs.gsheetwithimage;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class REGISTRATION extends AppCompatActivity {

    private EditText NAME,EMAIL,PHONENUM,PASSWORD,CONPASSWORD;
    private Button REGISTER;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        NAME = (EditText) findViewById(R.id.etName);
        EMAIL =(EditText) findViewById(R.id.etEmail);
        PHONENUM =(EditText) findViewById(R.id.etPhoneNum);
        // USERNAME =(EditText) findViewById(R.id.etAccName);
        PASSWORD = (EditText) findViewById(R.id.etPassword);
        CONPASSWORD =(EditText) findViewById(R.id.etConfirmPassword);
        REGISTER = (Button) findViewById(R.id.btnRegister);

        REGISTER.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register_onClick(view);
            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }


    public void register_onClick(View view){
        try{

            String name = NAME.getText().toString();
            String email = EMAIL.getText().toString();
            String phonenum = PHONENUM.getText().toString();
            String password = PASSWORD.getText().toString();
            String cpassword = CONPASSWORD.getText().toString();

            AccountDB accountDB = new AccountDB(getApplicationContext());
            Account account = new Account();


            account.setName(name);
            account.setEmail(email);
            account.setPhonenum(phonenum);
            // account.setUsername(USERNAME.getText().toString());
            account.setPassword(password);
            account.setConpassword(cpassword);


            Account temp = accountDB.checkEmail(email);

            if (temp == null) {

                 if(name.isEmpty() || email.isEmpty() || phonenum.isEmpty() || password.isEmpty() || cpassword.isEmpty()){

                    Toast.makeText(REGISTRATION.this, "Fill all the information", Toast.LENGTH_SHORT).show();

                }

                else if (! cpassword.equals(password)) {

                    Toast.makeText(REGISTRATION.this, "Password not matching", Toast.LENGTH_SHORT).show();

                }


                else {

                    accountDB.create(account);

                    Toast.makeText(getApplicationContext(), "REGISTRATION SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(REGISTRATION.this, LOGIN.class);
                    startActivity(intent);

                }

            }else{

                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setTitle(R.string.error);
                builder.setMessage(R.string.email_exists);
                builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                builder.show();
            }

        }catch(Exception e){
            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
            builder.setTitle(R.string.error);
            builder.setMessage(e.getMessage());
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            builder.show();
        }
    }

}
